import pygame as pg
from matrix_f import *
import re
import socket
import serial
import time

UDP_IP = "127.0.0.1"  # HOST
UDP_PORT = 55278  # Номер порта


class CondorMain:
    def __init__(self, render, start_pos, zero_pos, start_rot, down_main):
        self.render = render
        self.start_pos = start_pos
        self.zero_pos = zero_pos
        self.start_rot = start_rot
        self.down_main = down_main
        self.G = (1.7225, 0.3, 0.01, 1)  # Координаты точек верхнего основания
        self.K = (-0.8575, 0.3, 1.5, 1)
        self.T = (-0.8575, 0.3, -1.5, 1)
        self.vertexes = np.array([self.G, self.K, self.T,
                                  (1.3820, -1, -2.3937, 1), (1.3820, -1, -2.3937, 1), (1.3820, -1, 2.3937, 1),
                                  (1.3820, -1, 2.3937, 1), (-2.7532, -1, 0, 1),
                                  (-2.7532, -1, 0, 1)])  # Массив точек(тело)
        self.faces = np.array([(0, 1), (1, 2), (2, 0), (3, 0), (4, 2), (8, 2), (7, 1), (1, 5), (6, 0)])  # Линии
        self.translate(self.start_pos, start=True)
        self.font = pg.font.SysFont('Arial', 10, bold=True)
        self.font_tip = pg.font.SysFont('calibri', 12, bold=True)
        self.colors = [pg.Color('brown'), pg.Color('brown'), pg.Color('brown'), pg.Color('green'), pg.Color('cyan'),
                       pg.Color('red'), pg.Color('white'), pg.Color('yellow'), pg.Color('purple')]
        self.color_faces = [(color, face) for color, face in zip(self.colors, self.faces)]
        self.UPDm = []  # Массив для хранения градусной меры поворота(1 - pitch, 2 - yaw) из массива(не преобразованный)
        self.UDP1 = []  # Массив для первичного значения pitch
        self.UDP2 = []  # Массив для вторичного знания pitch
        self.UDP3 = []  # Массив для первичного значения bank
        self.UDP4 = []  # Массив для вторичного значения bank
        self.UDP5 = []  # Массив для первичного значения yaw
        self.UDP6 = []  # Массив для вторичного значения yaw
        self.dealta_PP = np.array([0, 0, 0, 0, 0, 0])  # Массив для хранения изменения длин поршней
        self.out_data = [0, 0, 0, 0, 0, 0]  # Выходные данные, для отправки на плату
        self.out_data_v = [0, 0, 0, 0, 0, 0]  # Выходные данные, для отправки на плату
        self.rot = []  # Массив для хранения градусной меры поворота(1 - pitch, 2 - yaw) из массива(преобразованный)
        self.label = False  # Флаг отрисовки координат точек
        self.movement_flag, self.draw_vertexes = True, False  # Флаг возможности перемещения; Отрисовка кругов в местах стыка
        self.move_1, self.move_2, self.move_3, self.move_c = False, False, False, False
        self.calibration_start = False
        self.draw_limits = self.render.calibration_mode
        self.a = 0

        self.max_l = [0, 0, 0, 0, 0, 0]
        self.min_l = [0, 0, 0, 0, 0, 0]
        self.middle = [0, 0, 0, 0, 0, 0]
        self.unlock_gate = [0, 0, 0, 0, 0, 0]

        self.g_test_x = [0, 0, 0]
        self.index_g = 0

        self.x = 0
        self.y = 0
        self.z = 0

        self.time = 0
        self.data_times = []

        self.start_orientation()
        self.start_vertexes = self.vertexes
        self.read_test = []  # массив для данных сценария полёта
        self.read_number = 0  # переменная циклов для сценария

    def start_orientation(self):
        self.rotate_x(self.start_rot[0], start=True)
        self.rotate_y(self.start_rot[1], start=True)
        self.rotate_z(self.start_rot[2], start=True)

    def draw(self):  # Метод отрисовки
        self.screen_projection()
        self.draw_limits_things()
        # ----Движения для демонстрации----
        self.move_translate()
        self.move_translate_colibaration()
        self.move_rotate_y()
        self.scenario()
        # ----Движения для демонстрации----
        self.calibration_move()

    def idle(self):
        self.vertexes = self.start_vertexes

    # --------ДЕМОНСТРАЦИЯ----------
    def scenario(self):
        """Работа платформы по заранее написанному сценарию!
        При нажатии на 't' поднимается флаг. Считываем из текстового файлы разницу значений
        положений, на которую и поворачиваем. Синхронизация происходит по времени из UDP порта.
        Порт плохо работает при повторе полёта записанного. Небходимо для адекватной работы
        Каждый раз перезапускать просмотр полета."""
        if self.move_c:
            sock = socket.socket(socket.AF_INET,  # Интернет
                                 socket.SOCK_DGRAM)  # UDP
            sock.bind((UDP_IP, UDP_PORT))
            data, addr = sock.recvfrom(10000)  # Размер буфера передачи
            a = data.decode("utf-8")  # Перекодировка содержимого из байт-строк в строки
            time_in = a.find('time=') + 5  # индекс начала времени + 5 символов (букв)
            time_out = a.find('airspeed=') - 3
            time_work = a[time_in:time_out]
            print(time_work)
            data_past_raw = self.read_test[self.read_number - 1]  # предыдущее значение положения
            data_raw = self.read_test[self.read_number]  # настоящее положение
            data = data_raw.split()
            data_past = data_past_raw.split()
            if float(time_work) >= float(data[0]):  # как только достигли нужного времени, начинаем крутить
                self.rotate_x((float(data[1]) - float(data_past[1])))
                self.rotate_y((float(data[2]) - float(data_past[2])))
                self.rotate_z((float(data[3]) - float(data_past[3])))
                self.read_number += 1  # переменная кол-ва циклов
                '''как только переменная становиться равной длине массива с данными, то обнуляем её и сбрасываем флаг'''
                if self.read_number == len(self.read_test) - 5:
                    self.read_number = 0
                    self.move_c = False

    def scenario_old(self):
        if self.move_c:
            var = 0
            zero = 0
            if (self.time + 0) < self.render.time < (self.time + self.data_times[0] * 1000):
                var, zero = 255, 255
            if (self.time + self.data_times[0] * 1000) < self.render.time < (
                    self.time + sum(self.data_times[:2]) * 1000):
                var, zero = -255, -255
            if (self.time + sum(self.data_times[:2]) * 1000) < self.render.time < (
                    self.time + sum(self.data_times[:3]) * 1000):
                var, zero = 255, 255
            if (self.time + sum(self.data_times[:3]) * 1000) < self.render.time < (
                    self.time + sum(self.data_times[:4]) * 1000):
                var, zero = 255, -255
            if (self.time + sum(self.data_times[:4]) * 1000) < self.render.time < (
                    self.time + sum(self.data_times[:5]) - self.data_times[4] / 2) * 1000:
                var, zero = -255, 255
            if (self.time + sum(self.data_times[:5]) - self.data_times[4] / 2) * 1000 < self.render.time < (
                    self.time + sum(self.data_times[:5]) * 1000):
                var, zero = -255, 255
            if (self.time + sum(self.data_times[:5]) * 1000) < self.render.time < (
                    self.time + sum(self.data_times) * 1000):
                var, zero = 255, -255
            '''if (self.time + sum(self.data_times) * 1000) < self.render.time < (
                    self.time + (sum(self.data_times) + self.data_times[1]) * 1000):
                var, zero = -255, -255'''
            if self.time + sum(self.data_times) * 1000 < self.render.time:
                self.move_c = False
                self.move_1 = True

            if self.move_c:
                outlet_com = '$' + str(var) + ' ' + str(zero) + ' ' + str(var) + ' ' + str(zero) + ' ' + str(
                    var) + ' ' + str(zero) + ';' + '\r\n'
                self.render.port_SPP.write(outlet_com.encode('utf-8'))
                time.sleep(0.002)

    def move_translate(self):
        if self.move_1:
            speed = 0.01
            self.a += 0.1
            if 0 < self.a < 10:
                self.translate([-speed, 0.00, 0.00])
            if 10 < self.a < 30:
                self.translate([speed, 0.00, 0.00])
            if 30 < self.a < 40:
                self.translate([-speed, 0.00, 0.00])
            if 40 < self.a < 50:
                self.translate([0.00, 0.00, -speed])
            if 50 < self.a < 70:
                self.translate([0.00, 0.00, speed])
            if 70 < self.a < 80:
                self.translate([0.00, 0.00, -speed])
            if self.a > 80:
                self.move_1 = False
                self.a = 0
            time.sleep(0.002)

    def move_translate_colibaration(self):
        if self.move_2:
            self.a += 0.1
            if 0 < self.a < 3:
                self.translate([0.00, 0.01, 0.00])
            if self.a > 3:
                self.move_2 = False
                self.a = 0

    def move_rotate_y(self):
        if self.move_3:
            self.a += 0.1
            if 0 < self.a < 5:
                # self.translate([0.00, 0.00, 0.00])
                self.rotate_y(-0.005)
                # self.translate([3, 2, 3])
            if 5 < self.a < 10:
                # self.translate([0.00, 0.00, 0.00])
                self.rotate_y(0.005)
                # self.translate([3, 2, 3])
            if self.a > 10:
                self.move_3 = False
                self.a = 0

    def demonstration_mode(self):
        key = pg.key.get_pressed()
        if key[pg.K_t]:
            self.move_c = True
            self.time = self.render.time
            file = open("DemostrationMode.txt", 'r')
            data = file.readline()
            self.data_times = data.split()
            self.data_times = [int(number) for number in self.data_times]
            file.close()

            f = open("Demonstration_Air.txt", 'r')
            self.read_test = f.readlines()
            f.close()

    def hand_mode(self):
        speed = 0.005
        key = pg.key.get_pressed()
        if key[pg.K_a] and self.move_2 is False and self.move_3 is False:
            self.move_1 = True
            # self.translate([-speed, 0.00, 0.00])
        if key[pg.K_d] and self.move_1 is False and self.move_3 is False:
            self.move_2 = True
            # self.translate([speed, 0.00, 0.00])
        if key[pg.K_w] and self.move_1 is False and self.move_2 is False:
            self.move_3 = True
            # self.translate([0.00, speed, 0.00])

        if key[pg.K_q]:
            self.rotate_y(speed)
            self.y += speed
        if key[pg.K_e]:
            self.rotate_y(-speed)
            self.y -= speed

        if key[pg.K_LEFT]:
            self.rotate_z(speed)
            self.z += speed
        if key[pg.K_RIGHT]:
            self.rotate_z(-speed)
            self.z -= speed
        if key[pg.K_UP]:
            self.rotate_x(speed)
            self.x += speed
        if key[pg.K_DOWN]:
            self.rotate_x(-speed)
            self.x -= speed

        time.sleep(0.03)

        print(self.x, self.y, self.z)

    # --------ДЕМОНСТРАЦИЯ----------

    # --------КАЛИБРОВКА----------
    def calibration(self):
        key = pg.key.get_pressed()
        if key[pg.K_s]:
            self.calibration_start = True

    def calibration_move(self):
        y = 170
        if self.calibration_start:
            self.translate([0.00, 0.05, 0.00])
            for index in range(1, 7):  # Подготовка данных для отсылки в порт
                self.out_data[index - 1] = str(round(float(y), 2))
            outlet_com = '$' + self.out_data[0] + ' ' + self.out_data[1] + ' ' + self.out_data[2] + ' ' + self.out_data[3] + ' ' + self.out_data[4] + ' ' + self.out_data[5] + ';'
            self.render.port_SPP.write(outlet_com.encode('utf-8'))

    # --------КАЛИБРОВКА----------

    def UPD(self):
        if self.render.simulate_mode:
            sock = socket.socket(socket.AF_INET,  # Интернет
                                 socket.SOCK_DGRAM)  # UDP
            sock.bind((UDP_IP, UDP_PORT))
            # print("[*] Port %d: Open" % (UDP_PORT))
            data, addr = sock.recvfrom(10000)  # Размер буфера передачи
            a = data.decode("utf-8")  # Перекодировка содержимого из байт-строк в строки
            time_in = a.find('time=')  + 5 # Индекс начала парметра
            time_out = a.find('airspeed=') - 3
            index_in = a.find('pitch=')  # Индекс начала парметра
            index_out = a.find('bank=')  # Из индекса начала след.парметра вычитаем символ переноса
            index_in2 = a.find('bank=')  # Индекс начала парметра
            index_out2 = a.find('quaternionx=')  # Из индекса начала след.парметра вычитаем символ переноса
            index_in3 = a.find('yawstringangle=')  # Индекс начала парметра
            index_out3 = a.find('radiofrequency=')  # Из индекса начала след.парметра вычитаем символ переноса
            self.UPDm.append(a[index_in:index_out])  # Добавляем в массив вырeз
            self.UPDm.append(a[index_in2:index_out2])  # Добавляем в массив вырeз
            self.UPDm.append(a[index_in3:index_out3])  # Добавляем в массив вырeз
            time = a[time_in:time_out]
            transf = re.findall(r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)', self.UPDm[0])  # Вычленяем числа из строки
            transf2 = re.findall(r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)', self.UPDm[1])  # Вычленяем числа из строки
            transf3 = re.findall(r'[-+]?(?:\d+(?:\.\d*)?|\.\d+)', self.UPDm[2])  # Вычленяем числа
            if len(self.UDP1) == 0 and len(self.UDP2) == 0 and len(self.UDP3) == 0 and len(self.UDP4) == 0 and len(
                    self.UDP5) == 0 and len(self.UDP6) == 0:
                self.UDP1 = [float(i) for i in transf]  # Превращаем в вещественные
                self.UDP3 = [float(i) for i in transf2]  # Превращаем в вещественные
                self.UDP5 = [float(i) for i in transf3]  # Превращаем в вещественные
                self.rot.append(float(self.UDP1[0]))  # Добавляем в массив с переменными вращения значение
                self.rot.append(float(self.UDP3[0]))  # Добавляем в массив с переменными вращения значение
                self.rotate_z(-(math.pi * self.rot[0]) / 21)  # Поварачиваем
                self.rotate_x(-(math.pi * self.rot[1]) / 21)  # Поварачиваем
                #  print(self.rot[0])
            if len(self.UDP1) != 0 and len(self.UDP2) == 0 and len(self.UDP3) != 0 and len(self.UDP4) == 0 and len(
                    self.UDP5) != 0 and len(self.UDP6) == 0:
                self.UDP2 = [float(i) for i in transf]
                self.UDP4 = [float(i) for i in transf2]
                self.UDP6 = [float(i) for i in transf3]
                self.rot.append(float(self.UDP2[0]) - float(self.UDP1[0]))
                self.rot.append(float(self.UDP4[0]) - float(self.UDP3[0]))
                self.rot.append(float(self.UDP6[0]) - float(self.UDP5[0]))
                self.rotate_z(-(math.pi * self.rot[0]) / 21)
                self.rotate_x(-(math.pi * self.rot[1]) / 21)
                self.rotate_y(-(math.pi * self.rot[2]) / 21)  # Поварачиваем
                #  print(self.rot[0])
                self.UDP1.clear()  # Очищаем нужные массивы для дальнейшей работы
                self.UDP3.clear()
                self.UDP5.clear()
            if len(self.UDP1) == 0 and len(self.UDP2) != 0 and len(self.UDP3) == 0 and len(self.UDP4) != 0 and len(
                    self.UDP5) == 0 and len(self.UDP6) != 0:
                self.UDP1 = [float(i) for i in transf]
                self.UDP3 = [float(i) for i in transf2]
                self.UDP5 = [float(i) for i in transf3]
                self.rot.append(float(self.UDP1[0]) - float(self.UDP2[0]))
                self.rot.append(float(self.UDP3[0]) - float(self.UDP4[0]))
                self.rot.append(float(self.UDP5[0]) - float(self.UDP6[0]))
                self.rotate_z(-(math.pi * self.rot[0]) / 21)
                self.rotate_x(-(math.pi * self.rot[1]) / 21)
                self.rotate_y(-(math.pi * self.rot[2]) / 21)
                #  print(self.rot[0])
                self.UDP2.clear()  # Очищаем нужные массивы для дальнейшей работы
                self.UDP4.clear()
                self.UDP6.clear()
            self.UPDm.clear()  # Очищаем массив для след. приёма
            f = open("Demonstration_Air.txt", 'a')
            f.write(str(time) + " " + str(self.x) + " " + str(self.y) + " " + str(self.z) + '\n')
            f.close()
            self.rot.clear()

    def lenPistons(self, s, f):  # Функция вычислени длины поршня
        try:
            pistonN_s = self.vertexes[s]  # Начальная точка поршня
            pistonN_f = self.vertexes[f]  # Конечная
            lenN_x = float(pistonN_s[0]) - float(pistonN_f[0])  # Разницы по 3-м координатам
            lenN_y = float(pistonN_s[1]) - float(pistonN_f[1])
            lenN_z = float(pistonN_s[2]) - float(pistonN_f[2])
            lenN = math.sqrt(
                lenN_x ** 2 + lenN_y ** 2 + lenN_z ** 2)  # Длина поршня вычисляется как диагональ прмямоугольного
            # параллипипида
            return lenN  # Возвращает длину поршня
        except IndexError:
            print('Ошибка в функции вычисления длины виртуального штока (основание без гироскопа)!')

    def draw_limits_things(self):
        """Функция для отрисовки критических(предельных) точек и поверхностей."""
        faces = [(3, 0), (4, 2), (8, 2), (7, 1), (5, 1), (6, 0)]  # массив с face - цилиндрами
        limit_vertexes_down = []  # массив для нижних критических точек
        limit_vertexes_up = []  # массив для верхних криических точек
        limit_vertexes_middle = []  # массив для средних криических точек
        limit_main = [limit_vertexes_down, limit_vertexes_up, limit_vertexes_middle]  # объединённый массив

        '''Создаётся экран для отображения поверхности ограничейний.
        Со свойствами альфа канала! Размером с основною рабочую, чтоб совпадали координаты!'''
        limits_screen = pg.Surface((self.render.H_WIDTH * 2, self.render.H_HEIGHT * 2))
        limits_screen.fill((255, 255, 255, 25))
        limits_screen.set_alpha(25)

        for face in enumerate(faces):  # бежим по списку face
            index, face = face

            up_point = self.vertexes[face[0]]
            down_point = self.vertexes[face[1]]

            dx = float(up_point[0]) - float(down_point[0])  # Разницы по 3-м координатам
            dy = float(up_point[1]) - float(down_point[1])
            dz = float(up_point[2]) - float(down_point[2])
            l_now = math.sqrt(
                dx ** 2 + dy ** 2 + dz ** 2)

            if l_now >= self.middle[0]:  # если достигли середины, то останавливаем площадку! (калибровка)
                self.calibration_start = False

            position = pg.Vector3([dx, dy, dz])  # представляем в виде вектора в 3-м измерении
            normal = position.normalize()  # нормализуем вектор для получения направления

            # -- Рассчитываются предельные точки и средняя --

            normal_down = normal * 3  # задаём ограничение внизу путём умножения единичного вектора на нужную длину
            normal_down = list(normal_down)  # вектор переводим в список
            normal_down.append(1)  # добавляем 1 в конце для перехода в 4-е пространство (рабочее)

            normal_up = normal * 3.8  # задаём ограничение наверху путём умножения единичного вектора на нужную длину
            normal_up = list(normal_up)
            normal_up.append(1)

            normal_mid = normal * 3.4  # задаём среднюю точку - с которой будет начинаться работа
            normal_mid = list(normal_mid)
            normal_mid.append(1)

            limit_point_down = (up_point[0] - normal_down[0], up_point[1] - normal_down[1],
                                up_point[2] - normal_down[2], 1)  # ставим точку на цилиндре
            limit_point_up = (up_point[0] - normal_up[0], up_point[1] - normal_up[1], up_point[2] - normal_up[2], 1)
            limit_point_middle = (up_point[0] - normal_mid[0], up_point[1] - normal_mid[1],
                                  up_point[2] - normal_mid[2], 1)

            # -- Рассчитываются предельные точки и средняя --

            limit_vertexes_down.append(limit_point_down)
            limit_vertexes_up.append(limit_point_up)
            limit_vertexes_middle.append(limit_point_middle)

            # -- Заполнение self.max_l and self.min_l --
            '''Вычисляется максимально и минимально допустимая длина цилиндра со штоком. Если
            длина штока с цилиндром будет превышать данную максимальную, то данные поступать на плату не будут!'''
            dx = float(limit_point_up[0]) - float(up_point[0])  # верхняя ограничительная - точка основания
            dy = float(limit_point_up[1]) - float(up_point[1])
            dz = float(limit_point_up[2]) - float(up_point[2])
            l_max = math.sqrt(
                dx ** 2 + dy ** 2 + dz ** 2)
            self.max_l[index] = l_max

            dx = float(limit_point_middle[0]) - float(up_point[0])  # верхняя ограничительная - точка основания
            dy = float(limit_point_middle[1]) - float(up_point[1])
            dz = float(limit_point_middle[2]) - float(up_point[2])
            l_mid = math.sqrt(
                dx ** 2 + dy ** 2 + dz ** 2)
            self.middle[index] = l_mid

            dx = float(limit_point_down[0]) - float(up_point[0])  # нижняя ограничительная - точка основания
            dy = float(limit_point_down[1]) - float(up_point[1])
            dz = float(limit_point_down[2]) - float(up_point[2])
            l_min = math.sqrt(
                dx ** 2 + dy ** 2 + dz ** 2)
            self.min_l[index] = l_min
            # -- Заполнение self.max_l and self.min_l--

        angle_array = []
        centre = (0, limit_vertexes_middle[0][1], 0, 1)

        vector1 = np.array(limit_vertexes_up[0][:3]) - np.array(centre[:3])
        vector1 = [vector1[0], vector1[1], vector1[2]]
        n_1 = pg.Vector3(vector1)
        n_1 = n_1.normalize()

        vector2 = np.array(limit_vertexes_down[0][:3]) - np.array(centre[:3])
        vector2 = [vector2[0], vector2[1], vector2[2]]
        n_2 = pg.Vector3(vector2)
        n_2 = n_2.normalize()

        angle_array.append(centre)
        vector_up = np.array(limit_vertexes_up[0][:3]) + np.array(n_1)
        vector_up = list(vector_up)
        vector_up.append(1)
        angle_array.append(vector_up)
        angle_array.append(centre)
        vector_down = np.array(limit_vertexes_down[0][:3]) + np.array(n_2)
        vector_down = list(vector_down)
        vector_down.append(1)
        angle_array.append(vector_down)

        l_1 = math.sqrt(
            vector1[0] ** 2 + vector1[1] ** 2 + vector1[2] ** 2)
        l_2 = math.sqrt(
            vector2[0] ** 2 + vector2[1] ** 2 + vector2[2] ** 2)

        angle = np.dot(vector1, vector2) / (l_1 * l_2)
        angle = np.arccos(angle) * 180 / 3.14
        # print(angle)

        limit_main.append(angle_array)

        for points in limit_main:  # сначала для нижних потом для верхних
            vertexes = points @ self.render.camera.camera_matrix()
            vertexes = vertexes @ self.render.projection.projection_matrix
            vertexes /= vertexes[:, -1].reshape(-1, 1)
            vertexes[(vertexes > 3) | (vertexes < -3)] = 0  # Отрисовка линий при определённой близости камеры к объекту
            vertexes = vertexes @ self.render.projection.to_screen_matrix
            vertexes = vertexes[:, :2]  # перевод в 2d, то есть в систему экрана

            if self.draw_limits:
                '''Синяя поверхность, если длина в пределах нормы и красная - если нет!'''
                if points != limit_vertexes_middle and points != angle_array:
                    if np.all(self.unlock_gate):
                        pg.draw.polygon(limits_screen, (135, 206, 235), vertexes)  # рисуем поверхность ограничений
                    else:
                        pg.draw.polygon(limits_screen, (255, 99, 71), vertexes)  # рисуем поверхность ограничений
                elif points == angle_array:
                    pg.draw.line(limits_screen, (255, 0, 0), vertexes[0], vertexes[1], 2)
                    pg.draw.line(limits_screen, (255, 0, 0), vertexes[2], vertexes[3], 2)
                    text = self.font_tip.render('Угол рабочей зоны: ' + str(round(angle, 2)),
                                                True,
                                                pg.Color('white'))
                    self.render.screen.blit(text, (vertexes[1][0], vertexes[1][1]))
                else:
                    pg.draw.polygon(limits_screen, (0, 255, 0), vertexes)

                self.render.screen.blit(limits_screen, (0, 0))  # отображаем на нашем спец. поверхности
                for vertex in vertexes:
                    pg.draw.circle(self.render.screen, pg.Color('red'), vertex, 2)  # рисуем точки на цилиндре
        # -- Блок подготовки возвращаемой величины --

    def info_canal(self):  # Элемент GUI - показ длин порpipшней
        P1 = self.lenPistons(0, 3)  # Перечень поршней
        P2 = self.lenPistons(4, 2)
        P3 = self.lenPistons(8, 2)
        P4 = self.lenPistons(7, 1)
        P5 = self.lenPistons(1, 5)
        P6 = self.lenPistons(6, 0)
        PP = np.array([P1, P2, P3, P4, P5, P6])  # Массив с длинами всех поршней
        self.render.l = PP
        self.render.bars = (PP - self.min_l[0]) / (self.max_l[0] - self.min_l[0])
        d = PP - self.dealta_PP

        # -- Заполенение unlock_gate --
        '''Заполняется булевый массив, который играет роль "ключа" на отправку данных.
        То есть, если длина выше минимальной и не превышает максимальную, то True(открыт)'''
        for p in enumerate(PP):
            index, l = p
            if self.min_l[index] <= l <= self.max_l[index]:
                self.unlock_gate[index] = True
            else:
                self.unlock_gate[index] = False
        # -- Заполенение unlock_gate --

        '''for index in range(1, 7):  # Вывод на экран длин поршней
            new_len = round(PP[index - 1], 4)
            new_dealta = round((d[index - 1] / 0.05), 4)
            \text = self.font_tip.render('Длина П' + str(index) + ':' + str(new_len) + "," + str(new_dealta), True,
                                        pg.Color('black'))
            self.render.screen.blit(text, (20, 50 + 30 * index))
            pg.draw.rect(self.render.screen, self.colors[index + 2], (4, 60 + 30 * index, 5, 7))

        for index in range(0, 6):  # Отрисовка кругов дельты(красный-отрицательна;зелёный - положительна)
            if d[index] > 0:
                pg.draw.circle(self.render.screen, pg.Color('green'), (15, 85 + 30 * index), 2)
            elif d[index] < 0:
                pg.draw.circle(self.render.screen, pg.Color('red'), (15, 85 + 30 * index), 2)
            else:
                pg.draw.circle(self.render.screen, pg.Color('white'), (15, 85 + 30 * index), 2)'''

        for index in range(1, 7):  # Подготовка данных для отсылки в порт
            v = round(d[index - 1] / 0.03,
                      3)
            '''Последний шаг: непосредственно присваивание значений в зависимости от того, 
            какой "ключ". Если у цилиндра "ключ" == False, то посылается "0" и шток не двигается!'''
            if self.unlock_gate[index - 1]:
                y = (255 * v) / 0.25
            else:
                y = 0
            if not self.calibration_start or not self.render.reload:
                self.out_data[index - 1] = str(round(float(y), 2))
            elif y > 10000:
                y = 0
                self.out_data[index - 1] = str(round(float(y), 2))

        outlet_com = '$' + self.out_data[3] + ' ' + self.out_data[4] + ' ' + self.out_data[5] + ' ' + self.out_data[0] + ' ' + self.out_data[1] + ' ' + self.out_data[2] + ';' + '\r\n'
        # if not self.render.reload and not self.move_c and not self.calibration_start:
        #print(outlet_com)
        if not self.render.reload and not self.calibration_start:
            self.render.port_SPP.write(outlet_com.encode('utf-8'))
            if not self.render.simulate_mode:
                time.sleep(0.003)
        self.dealta_PP = PP

    def screen_projection(self):  # Метод проекции объекта и отрисовки связей
        vertexes = self.vertexes @ self.render.camera.camera_matrix()  # Точки объекта на положение камеры = нынешняя проекция объекта
        vertexes = vertexes @ self.render.projection.projection_matrix  # Далее рендерим
        vertexes /= vertexes[:, -1].reshape(-1, 1)
        vertexes[(vertexes > 3) | (vertexes < -3)] = 0  # Отрисовка линий при определённой близости камеры к объекту
        vertexes = vertexes @ self.render.projection.to_screen_matrix
        vertexes = vertexes[:, :2]

        for index, color_face in enumerate(self.color_faces):
            color, face = color_face
            polygon = vertexes[face]
            if not np.any((polygon == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)) and \
                    self.render.hand_mode_draw[index]:
                pg.draw.polygon(self.render.screen, color, polygon, 1)  # рисуем полигон из массива vertexes[face]
                if self.label == True:  # polygon[0] - начальная точка полигона(линии)  # Отрисовывем координаты
                    # точек на начальной точке
                    text = self.font.render(str(self.vertexes[index]), True, pg.Color('white'))
                    self.render.screen.blit(text, polygon[0])

            if self.draw_vertexes:  # если флаг отрисовки кругов в местах соединений True
                for vertex in vertexes:
                    if not np.any((vertex == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)):
                        pg.draw.circle(self.render.screen, pg.Color('white'), vertex, 2)

    ### МЕТОДЫ ИЗМЕНЕНИЯ ПОЛОЖЕНИЯ ОБЪЕКТА###

    def constants(self):
        self.vertexes[3], self.vertexes[4] = self.down_main.vertexes[0], self.down_main.vertexes[0]
        self.vertexes[5], self.vertexes[6] = self.down_main.vertexes[1], self.down_main.vertexes[1]
        self.vertexes[7], self.vertexes[8] = self.down_main.vertexes[2], self.down_main.vertexes[2]

        '''for _ in range(3, 9):
            self.vertexes[_] = self.vertexes[_] @ translate(self.start_pos)'''

    def translate(self, pos, start=False):
        if not start:
            self.vertexes = self.vertexes @ rotate_x(-self.start_rot[0])
            self.vertexes = self.vertexes @ rotate_y(-self.start_rot[1])
            self.vertexes = self.vertexes @ rotate_z(-self.start_rot[2])

            self.vertexes = self.vertexes @ translate(pos)

            self.vertexes = self.vertexes @ rotate_z(self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_y(self.start_rot[1])
            self.vertexes = self.vertexes @ rotate_x(self.start_rot[0])
        else:
            self.vertexes = self.vertexes @ translate(pos)
        self.constants()

    def scale(self, scale_to):
        self.vertexes = self.vertexes @ scale(scale_to)

    def rotate_x(self, angle, start=False):
        if not start:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_y(-self.start_rot[1])
            self.vertexes = self.vertexes @ rotate_z(-self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_x(angle)
            self.vertexes = self.vertexes @ rotate_z(self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_y(self.start_rot[1])
            self.vertexes = self.vertexes @ translate(self.start_pos)
            self.x += angle
        else:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_x(angle)
            self.vertexes = self.vertexes @ translate(self.start_pos)
        self.constants()

    def rotate_y(self, angle, start=False):
        if not start:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_x(-self.start_rot[0])
            self.vertexes = self.vertexes @ rotate_z(-self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_y(angle)
            self.vertexes = self.vertexes @ rotate_z(self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_x(self.start_rot[0])
            self.vertexes = self.vertexes @ translate(self.start_pos)
            self.y += angle
        else:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_y(angle)
            self.vertexes = self.vertexes @ translate(self.start_pos)
        self.constants()

    def rotate_z(self, angle, start=False):
        if not start:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_x(-self.start_rot[0])
            self.vertexes = self.vertexes @ rotate_y(-self.start_rot[1])
            self.vertexes = self.vertexes @ rotate_z(angle)
            self.vertexes = self.vertexes @ rotate_y(self.start_rot[1])
            self.vertexes = self.vertexes @ rotate_x(self.start_rot[0])
            self.vertexes = self.vertexes @ translate(self.start_pos)
            self.z += angle
        else:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_z(angle)
            self.vertexes = self.vertexes @ translate(self.start_pos)
        self.constants()

    ### МЕТОДЫ ИЗМЕНЕНИЯ ПОЛОЖЕНИЯ ОБЪЕКТА###


class Axes:  # Дочерний класс - оси
    def __init__(self, render, start_pos, zero_pos, start_rot):
        self.render = render
        self.start_pos = start_pos
        self.zero_pos = zero_pos
        self.start_rot = start_rot
        self.vertexes = np.array([(0, 0, 0, 1), (1, 0, 0, 1), (0, 1, 0, 1), (0, 0, 1, 1)])
        self.faces = np.array([(0, 1), (0, 2), (0, 3)])
        self.colors = [pg.Color('blue'), pg.Color('red'), pg.Color('green'), pg.Color('blue')]
        self.color_faces = [(color, face) for color, face in zip(self.colors, self.faces)]
        self.draw_vertexes = False
        self.label = 'XYZ'
        self.font = pg.font.SysFont('Arial', 10, bold=True)
        self.translate(self.start_pos)
        self.rotate_x(self.start_rot[0])
        self.rotate_y(self.start_rot[1])
        self.rotate_z(self.start_rot[2])

    def draw(self):
        self.screen_projection()

    def translate(self, pos):
        self.vertexes = self.vertexes @ translate(pos)

    def scale(self, scale_to):
        self.vertexes = self.vertexes @ scale(scale_to)

    def rotate_x(self, angle):
        self.vertexes = self.vertexes @ translate(self.zero_pos)
        self.vertexes = self.vertexes @ rotate_x(angle)
        self.vertexes = self.vertexes @ translate(self.start_pos)

    def rotate_y(self, angle):
        self.vertexes = self.vertexes @ translate(self.zero_pos)
        self.vertexes = self.vertexes @ rotate_y(angle)
        self.vertexes = self.vertexes @ translate(self.start_pos)

    def rotate_z(self, angle):
        self.vertexes = self.vertexes @ translate(self.zero_pos)
        self.vertexes = self.vertexes @ rotate_z(angle)
        self.vertexes = self.vertexes @ translate(self.start_pos)

    def screen_projection(self):
        vertexes = self.vertexes @ self.render.camera.camera_matrix()
        vertexes = vertexes @ self.render.projection.projection_matrix
        vertexes /= vertexes[:, -1].reshape(-1, 1)
        vertexes[(vertexes > 2) | (vertexes < -2)] = 0
        vertexes = vertexes @ self.render.projection.to_screen_matrix
        vertexes = vertexes[:, :2]

        for index, color_face in enumerate(self.color_faces):
            color, face = color_face
            polygon = vertexes[face]
            if not np.any((polygon == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)):
                pg.draw.polygon(self.render.screen, color, polygon, 1)
                if self.label:
                    text = self.font.render(str(self.label[index]), True, pg.Color('white'))
                    self.render.screen.blit(text,
                                            polygon[-1])  # здесь на конце линии отрисовывается, и не координаты а label

            if self.draw_vertexes:
                for vertex in vertexes:
                    if not np.any((vertex == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)):
                        pg.draw.circle(self.render.screen, pg.Color('white'), vertex, 2)


class DownMain:
    def __init__(self, render, start_pos, start_rot, zero_pos):
        self.render = render
        self.start_pos = start_pos
        self.zero_pos = zero_pos
        self.start_rot = start_rot
        self.vertexes = np.array([(1.3820, -1.5, -2.3937, 1), (1.3820, -1.5, 2.3937, 1), (-2.7532, -1.5, 0, 1)])
        self.faces = np.array([(0, 1), (1, 2), (2, 0)])
        self.colors = [pg.Color('brown'), pg.Color('brown'), pg.Color('brown')]
        self.color_faces = [(color, face) for color, face in zip(self.colors, self.faces)]
        self.draw_vertexes = False
        self.label = False
        self.font = pg.font.SysFont('Arial', 10, bold=True)

        self.translate(self.start_pos)
        self.start_orientation()

    def start_orientation(self):
        self.rotate_x(self.start_rot[0])
        self.rotate_y(self.start_rot[1], start=True)
        self.rotate_z(self.start_rot[2])

    def draw(self):
        self.screen_projection()

    def translate(self, pos):
        self.vertexes = self.vertexes @ translate(pos)

    def rotate_x(self, angle):
        self.vertexes = self.vertexes @ translate(self.zero_pos)
        self.vertexes = self.vertexes @ rotate_x(angle)
        self.vertexes = self.vertexes @ translate(self.start_pos)

    def rotate_y(self, angle, start=False):
        if not start:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_x(-self.start_rot[0])
            self.vertexes = self.vertexes @ rotate_z(-self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_y(angle)
            self.vertexes = self.vertexes @ rotate_z(self.start_rot[2])
            self.vertexes = self.vertexes @ rotate_x(self.start_rot[0])
            self.vertexes = self.vertexes @ translate(self.start_pos)
        else:
            self.vertexes = self.vertexes @ translate(self.zero_pos)
            self.vertexes = self.vertexes @ rotate_y(angle)
            self.vertexes = self.vertexes @ translate(self.start_pos)

    def rotate_z(self, angle):
        self.vertexes = self.vertexes @ translate(self.zero_pos)
        self.vertexes = self.vertexes @ rotate_z(angle)
        self.vertexes = self.vertexes @ translate(self.start_pos)

    def screen_projection(self):
        vertexes = self.vertexes @ self.render.camera.camera_matrix()
        vertexes = vertexes @ self.render.projection.projection_matrix
        vertexes /= vertexes[:, -1].reshape(-1, 1)
        vertexes[(vertexes > 2) | (vertexes < -2)] = 0
        vertexes = vertexes @ self.render.projection.to_screen_matrix
        vertexes = vertexes[:, :2]

        for index, color_face in enumerate(self.color_faces):
            color, face = color_face
            polygon = vertexes[face]
            if not np.any((polygon == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)):
                pg.draw.polygon(self.render.screen, color, polygon, 1)
                if self.label:
                    text = self.font.render(str(self.label[index]), True, pg.Color('white'))
                    self.render.screen.blit(text,
                                            polygon[-1])  # здесь на конце линии отрисовывается, и не координаты а label

            if self.draw_vertexes:
                for vertex in vertexes:
                    if not np.any((vertex == self.render.H_WIDTH) | (polygon == self.render.H_HEIGHT)):
                        pg.draw.circle(self.render.screen, pg.Color('white'), vertex, 2)


class GyroMain(CondorMain):
    def __init__(self, render, start_pos, zero_pos, start_rot, down_main):
        super().__init__(render, start_pos, zero_pos, start_rot, down_main)
        self.dealta_PP = np.array([0, 0, 0, 0, 0, 0])
        self.zero_dealta = 0

    def draw(self):
        self.screen_projection()
        #self.gyro()

    def lenPistons(self, s, f):  # Функция вычислени длины поршня
        try:
            pistonN_s = self.vertexes[s]  # Начальная точка поршня
            pistonN_f = self.vertexes[f]  # Конечная
            if len(pistonN_s) == 4 and len(pistonN_f) == 4:
                lenN_x = float(pistonN_s[0]) - float(pistonN_f[0])  # Разницы по 3-м координатам
                lenN_y = float(pistonN_s[1]) - float(pistonN_f[1])
                lenN_z = float(pistonN_s[2]) - float(pistonN_f[2])
                lenN = math.sqrt(
                    lenN_x ** 2 + lenN_y ** 2 + lenN_z ** 2)  # Длина поршня вычисляется как диагональ прмямоугольного
                # параллипипида
                # print(pistonN_s, pistonN_f, '+')
                return lenN  # Возвращает длину поршня
        except IndexError:
            print(pistonN_s, pistonN_f, '-')
            print('Ошибка в функции вычисления длины виртуального штока (основание с гироскопом)!')

    def info_canal(self):  # Элемент GUI - показ длин порpipшней
        P1 = round(self.lenPistons(0, 3), 4)  # Перечень поршней
        P2 = round(self.lenPistons(4, 2), 4)
        P3 = round(self.lenPistons(8, 2), 4)
        P4 = round(self.lenPistons(7, 1), 4)
        P5 = round(self.lenPistons(1, 5), 4)
        P6 = round(self.lenPistons(6, 0), 4)

        PP = np.array([P1, P2, P3, P4, P5, P6])  # Массив с длинами всех поршней
        self.render.bars_gyro = (PP - self.render.condor_main.min_l[0]) / (
                    self.render.condor_main.max_l[0] - self.render.condor_main.min_l[0])
        self.render.l_gyro = PP

    def gyro(self):
        if self.render.port_gyro.inWaiting() > 0:
            a = self.render.port_gyro.read()
            if a == b'$':
                test_raw = self.render.port_gyro.read_until(b';')
                # print(test_raw)
                test = test_raw.decode("utf-8")
                test = test[:-1]
                data_convert = test.split(" ")
                for data in enumerate(data_convert):
                    index, error = data
                    if error == 'nan':
                        error = self.g_test_x[index]
                        data_convert[index] = error
                # print(data_convert)
                if len(data_convert) == 3:
                    b = float(data_convert[0]) - self.g_test_x[0]
                    c = float(data_convert[1]) - self.g_test_x[1]
                    v = float(data_convert[2]) - self.g_test_x[2]
                    self.rotate_z(b * math.pi / 180)
                    self.rotate_x(c * math.pi / 180)
                    self.rotate_y(v * math.pi / 180)
                    self.g_test_x = [float(data_convert[0]), float(data_convert[1]), float(data_convert[2])]
            self.index_g += 1
            self.render.port_gyro.flushInput()
            time.sleep(0.03)


class Controller:
    """Класс джойстика. Принимаем на вход id джойстика в списке доступных
    и подвижное основание, котрое будет двигать"""
    def __init__(self, id, main_programm):
        self.id = id
        self.main_programm = main_programm
        self.controller_init()

    def controller_init(self):
        self.controller = pg.joystick.Joystick(self.id)
        self.controller.init()
        self.axes = self.controller.get_numaxes()

    def control(self, axis, value):
        """1000, 2000 - коэфф. чувствительности!"""
        print(axis, value)
        if axis == 0:
            self.main_programm.rotate_x(value * math.pi / 1000)
        if axis == 1:
            self.main_programm.rotate_z(value * math.pi / 1000)
        if axis == 2:
            self.main_programm.rotate_y(value * math.pi / 2000)
