import pygame
from object import *
from projection import *
from camera import *
from InterfaceQt import *
import os
from PyQt5 import QtWidgets
import sys
import serial

class Simulation:  # Основной класс программы
    def __init__(self):
        self.y = 99
        self.x = 48
        pygame.init()
        os.environ['SDL_VIDEO_WINDOW_POS'] = "%d,%d" % (self.x, self.y)
        self.RES = self.WIDTH, self.HEIGHT = 451, 851  # разрешение
        self.H_WIDTH, self.H_HEIGHT = self.WIDTH // 2, self.HEIGHT // 2
        self.FPS = 120
        self.screen = pygame.display.set_mode(self.RES, pygame.NOFRAME)
        self.screen.fill(pygame.Color("gray"))
        self.clock = pygame.time.Clock()
        self.time = 0
        self.port_SPP = serial.Serial('COM3', 115200, timeout=500, writeTimeout=0)
        time.sleep(1)
        '''self.port_gyro = serial.Serial('COM4', 57600, parity=serial.PARITY_NONE, \
                                       stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS, \
                                       timeout=1000)'''
        self.modes()
        self.start_positions()
        self.create_object()
        self.data_to_ui()
        self.setings()

    def start_ports(self, ports):
        pass
        '''self.port_SPP = serial.Serial(ports[0], 115200, timeout=500, writeTimeout=0)
        time.sleep(1)
        self.port_gyro = serial.Serial(ports[1], 57600, parity=serial.PARITY_NONE, \
                                       stopbits=serial.STOPBITS_ONE, bytesize=serial.EIGHTBITS, \
                                       timeout=1000)'''

    def start_positions(self):
        self.start_pos_condor_main = [0, -3, 0]
        self.zero_pos_condor_main = [0, 3, 0]
        self.start_rot_condor_main = [0.475, 0, -0.27]

        self.start_pos_gyro_main = [0, 5, 0]
        self.zero_pos_gyro_main = [0, -5, 0]
        self.start_rot_gyro_main = [-0.72, 0.36, 0.12]

        self.start_pos_axes = [0, 0, 0]
        self.zero_pos_axes = [0, 0, 0]

    def modes(self):
        self.demonstration_mode = False
        self.calibration_mode = False
        self.hand_mode = False
        self.simulate_mode = False
        self.reload = False

    def setings(self):
        self.start_simulation = False
        self.unlock_UPD = False
        self.start_com = True
        self.quit = False

    def data_to_ui(self):
        self.l = [0, 0, 0, 0, 0, 0]
        self.l_gyro = [0, 0, 0, 0, 0, 0]
        self.bars = [0, 0, 0, 0, 0, 0]
        self.bars_gyro = [0, 0, 0, 0, 0, 0]
        self.hand_mode_draw = [True, True, True,
                               True, True, True,
                               True, True, True]
        self.spp = []

    def create_object(self):
        self.camera = Camera(self, [-2.57, 1.17, -4.49])
        self.camera.camera_yaw(math.pi / 6)
        #self.camera.camera_pitch(math.pi / 15)
        self.projection = Projection(self)

        self.condor_down_main = DownMain(self, start_pos=self.start_pos_condor_main, zero_pos=self.zero_pos_condor_main,
                                         start_rot=self.start_rot_condor_main)
        self.condor_down_main.rotate_y(-2.03 - 0.3+2.56-2.87)
        self.condor_main = CondorMain(self, start_pos=self.start_pos_condor_main, zero_pos=self.zero_pos_condor_main,
                                      start_rot=self.start_rot_condor_main, down_main=self.condor_down_main)
        self.condor_main.rotate_y(-2.03-0.3+2.56-2.87)
        self.gyro_down_main = DownMain(self, start_pos=self.start_pos_gyro_main,
                                       start_rot=self.start_rot_gyro_main, zero_pos=self.zero_pos_gyro_main)
        self.gyro_main = GyroMain(self, start_pos=self.start_pos_gyro_main, zero_pos=self.zero_pos_gyro_main,
                                 start_rot=self.start_rot_gyro_main, down_main=self.gyro_down_main)
        self.axes = Axes(self, start_pos=self.start_pos_condor_main, zero_pos=self.zero_pos_condor_main, start_rot=self.start_rot_condor_main)
        self.axes.movement_flag = False

        if pygame.joystick.get_count() == 1:
            self.controller = Controller(0, self.condor_main)

    def draw(self):
        self.screen.fill(pygame.Color("gray"))
        self.condor_main.draw()
        self.axes.draw()
        self.condor_down_main.draw()
        self.condor_main.info_canal()

        self.gyro_main.draw()
        self.gyro_main.info_canal()
        self.gyro_down_main.draw()

        if self.unlock_UPD or self.simulate_mode:
            self.condor_main.UPD()
        if self.calibration_mode:
            self.condor_main.calibration()

    def run(self):
        while True:
            if self.start_simulation:
                self.draw()
                self.time = pygame.time.get_ticks()
                if self.simulate_mode:
                    self.camera.control()
                elif self.hand_mode:
                    """Если включён ручной, то обрабатываем события и ищем среди них
                    манипуляции джойстиком. Передаём ось и значение поворота на ней в 
                    функцию управления контролллером! Также работают кнопки управления с клавы!"""
                    self.condor_main.hand_mode()
                    events = pygame.event.get()
                    for event in events:
                        if event.type == pygame.JOYAXISMOTION:
                            self.controller.control(event.axis, event.value)
                    # self.gyro_main.hand_mode()
                elif self.demonstration_mode:
                    self.condor_main.demonstration_mode()
            else:
                self.screen.fill(pygame.Color("gray"))
            for i in pygame.event.get():
                if i.type == pygame.QUIT:
                    exit()
            pygame.display.flip()
            #self.clock.tick(self.FPS)


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    QtWidgets.QApplication(sys.argv).exec()



