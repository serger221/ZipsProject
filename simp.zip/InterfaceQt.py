import sys
from PyQt5 import QtWidgets, QtCore, QtGui, QtMultimedia
import psutil
import pyqtgraph as pg
from collections import deque

from MainWindow import Ui_Platform
from ConsolWindow import Ui_Form
from LoadWindow import Ui_load_window

from main import Simulation
import pygame
import serial
import time
from datetime import datetime

texts_errors = ["Питание Arduino Nano №1", "Сигнал на реле Arduino Nano №1", "Сигнал на транзистор Arduino Nano №1",
                "Питание Arduino Nano №2", "Сигнал на реле Arduino Nano №2", "Сигнал на транзистор Arduino Nano №2",
                "Питание Arduino Nano №3", "Сигнал на реле Arduino Nano №3", "Сигнал на транзистор Arduino Nano №3",
                "Питание Arduino Nano №1", "Сигнал на реле Arduino Nano №4", "Сигнал на транзистор Arduino Nano №4",
                "Питание Arduino Nano №2", "Сигнал на реле Arduino Nano №5", "Сигнал на транзистор Arduino Nano №5",
                "Питание Arduino Nano №3", "Сигнал на реле Arduino Nano №6", "Сигнал на транзистор Arduino Nano №6"]


class MainWindow(QtWidgets.QMainWindow, Ui_Platform):
    def __init__(self):
        super(MainWindow, self).__init__()
        self.setupUi(self)
        self.setWindowTitle("Main Window")
        self.setWindowIcon(QtGui.QIcon("icons\ico.ico"))
        self.setGeometry(50, 50, 1460, 900)
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.press = False
        self.last_pos = QtCore.QPoint(0, 0)
        self.time_to_reload = 0

        self.can_reset = True
        self.count_of_zero = 0
        '''self.load = LoadWindow(self)
        self.load.show()'''
        self.run_methods()
        self.flags()

        self.timer = QtCore.QTimer()
        self.timer.setInterval(100)
        self.timer.timeout.connect(self.update)
        self.timer.timeout.connect(self.check_boxes_change)
        self.timer.timeout.connect(self.dynamic_characteristic)
        self.timer.start()

        self.show()
        self.platform = Simulation()
        self.platform.run()

    def run_platform(self, ports):
        self.timer.start()
        self.show()
        self.platform = Simulation(ports)
        self.platform.run()

    def clear_log(self):
        file = open("LogFileCOM.txt", "w").close()

    def run_methods(self):
        self.clear_log()
        self.set_mask()
        self.set_toolbar()
        self.create_plots()
        self.progress_bar()
        self.buttons()
        self.system_prepare()

    def flags(self):
        self.power_is_on = False
        self.power_is_off = True

    def set_mask(self):
        frameRect = self.frameGeometry()
        grabGeometry = self.pg_place.geometry()
        grabGeometry.moveTopLeft(self.mapToGlobal(QtCore.QPoint(0, 0)))
        frameRect.moveTopLeft(self.mapToGlobal(QtCore.QPoint(0, 0)))
        frameRect.moveTopLeft(QtCore.QPoint(0, 0))
        grabGeometry.moveTopLeft(QtCore.QPoint(50, 100))

        region = QtGui.QRegion(frameRect.adjusted(0, 0, 5, 5))
        region -= QtGui.QRegion(grabGeometry) + QtGui.QRegion(50, 630, 451, 213)

        self.setMask(region)
        self.move(-10, -32)

    def consol_window(self):
        self.consol = QtWidgets.QWidget()
        ui = Ui_Form()
        ui.setupUi(self.consol)
        self.consol.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.consol.show()

    def set_toolbar(self):
        exitAction = QtWidgets.QAction(QtGui.QIcon('icons\imd.png'), 'Закрыть', self)
        exitAction.setShortcut('Ctrl+Q')
        exitAction.setStatusTip('Закрыть приложение')
        exitAction.triggered.connect(self.exitProgram)

        minimizeAction = QtWidgets.QAction(QtGui.QIcon('icons\minimize.png'), 'Свернуть', self)
        minimizeAction.setShortcut('Ctrl+E')
        minimizeAction.setStatusTip('Свернуть приложение')
        minimizeAction.triggered.connect(self.showMinimized)
        minimizeAction.triggered.connect(pygame.display.iconify)

        self.statusBar()

        menubar = self.menuBar()
        fileMenu = menubar.addMenu('&Файл')
        fileMenu.addAction(exitAction)
        fileMenu.addAction(minimizeAction)
        modeMenu = menubar.addMenu('&Режимы')
        modeShow = QtWidgets.QAction(QtGui.QIcon('icons\modes.png'), 'Демонстрационный', self)
        modeShow.setStatusTip('Включить демонстрационный режим')
        modeShow.triggered.connect(self.show_mode)
        modeSetings = QtWidgets.QAction(QtGui.QIcon('icons\modes.png'), 'Калибровка', self)
        modeSetings.setStatusTip('Включить калибровочный режим')
        modeSetings.triggered.connect(self.calibration_mode)
        modeSimulate = QtWidgets.QAction(QtGui.QIcon('icons\modes.png'), 'Симуляция', self)
        modeSimulate.setStatusTip('Включить симуляционный режим')
        modeSimulate.triggered.connect(self.simulate_mode)
        modeCheck = QtWidgets.QAction(QtGui.QIcon('icons\modes.png'), 'Проверка', self)
        modeHand = QtWidgets.QAction(QtGui.QIcon('icons\modes.png'), 'Ручной', self)
        modeHand.setStatusTip('Включить ручной режим')
        modeHand.triggered.connect(self.hand_mode)
        modeMenu.addAction(modeShow)
        modeMenu.addAction(modeSetings)
        modeMenu.addAction(modeSimulate)
        modeMenu.addAction(modeCheck)
        modeMenu.addAction(modeHand)
        setingsMenu = menubar.addMenu('&Настройки')
        setingsOn = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Подключение симулятора', self)
        setingsCanals = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Разъёмы', self)
        setingsCanals.triggered.connect(self.set_ports)
        setingsWide = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Расширенные настройки', self)
        setingsConsol = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Консоль разработчика', self)
        setingsConsol.triggered.connect(ConsolWindow())
        setingsMenu.addAction(setingsOn)
        setingsMenu.addAction(setingsCanals)
        setingsMenu.addAction(setingsWide)
        setingsMenu.addAction(setingsConsol)
        helpMenu = menubar.addMenu('&Руководство')
        powerMenu = menubar.addMenu('&Питание')
        powerPowerOn = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Включить питание', self)
        powerPowerOn.triggered.connect(self.powerOn)
        powerPowerOff = QtWidgets.QAction(QtGui.QIcon('icons\setings.png'), 'Отключить питание', self)
        powerPowerOff.triggered.connect(self.powerOff)
        powerMenu.addAction(powerPowerOn)
        powerMenu.addAction(powerPowerOff)

        toolbar = self.addToolBar('Exit')
        self.addToolBar(QtCore.Qt.LeftToolBarArea, toolbar)
        toolbar.addAction(exitAction)
        toolbar.addAction(minimizeAction)

    def set_ports(self):
        self.load_ports = LoadWindow(self)
        self.load_ports.show()

    def create_plots(self):
        self.p1 = pg.PlotWidget()
        self.a = QtWidgets.QVBoxLayout(self.p1_plot_9)
        self.a.addWidget(self.p1)
        self.plot1 = Graph(self.p1)

        self.p2 = pg.PlotWidget()
        self.a2 = QtWidgets.QVBoxLayout(self.p1_plot_10)
        self.a2.addWidget(self.p2)
        self.plot2 = Graph(self.p2)

        self.p3 = pg.PlotWidget()
        self.a3 = QtWidgets.QVBoxLayout(self.p1_plot_11)
        self.a3.addWidget(self.p3)
        self.plot3 = Graph(self.p3)

        self.p4 = pg.PlotWidget()
        self.a4 = QtWidgets.QVBoxLayout(self.widget)
        self.a4.addWidget(self.p4)
        self.plot4 = Graph(self.p4)

        self.p5 = pg.PlotWidget()
        self.a5 = QtWidgets.QVBoxLayout(self.p1_plot_6)
        self.a5.addWidget(self.p5)
        self.plot5 = Graph(self.p5)

        self.p6 = pg.PlotWidget()
        self.a6 = QtWidgets.QVBoxLayout(self.p1_plot_7)
        self.a6.addWidget(self.p6)
        self.plot6 = Graph(self.p6)

        self.plots = [self.plot1, self.plot2, self.plot3,
                      self.plot4, self.plot5, self.plot6]

    def check_boxes_change(self):
        boxes = [self.checkBox_6, self.checkBox_5, self.checkBox_4,
                 self.checkBox_3, self.checkBox_2, self.checkBox]
        if self.platform.hand_mode:
            for box in enumerate(boxes):
                index, box = box
                if box.isChecked():
                    self.platform.hand_mode_draw[index + 3] = True
                elif not box.isChecked():
                    self.platform.hand_mode_draw[index + 3] = False
        else:
            for box in boxes:
                box.setEnabled(False)

        if self.checkBox_7.isChecked():
            self.reload()
            if not self.platform.reload:
                self.time_to_reload = self.platform.time
                self.platform.reload = True
        else:
            self.platform.reload = False

    def buttons(self):
        self.sound_button = QtMultimedia.QSound('sounds\click_button.wav', self)
        self.pushButton_7.clicked.connect(self.start_sim)
        self.pushButton_7.clicked.connect(self.sound_button.play)
        self.pushButton_8.clicked.connect(self.end_sim)
        self.pushButton_8.clicked.connect(self.sound_button.play)

    def progress_bar(self):
        self.bar1 = PassBar(self)
        self.bar1.move(780, 110)
        self.bar2 = PassBar(self)
        self.bar2.move(1070, 110)
        self.bar3 = PassBar(self)
        self.bar3.move(780, 380)
        self.bar4 = PassBar(self)
        self.bar4.move(1070, 380)
        self.bar5 = PassBar(self)
        self.bar5.move(780, 640)
        self.bar6 = PassBar(self)
        self.bar6.move(1070, 640)

        self.bar7 = PassBar(self)
        self.bar7.move(790, 110)
        self.bar8 = PassBar(self)
        self.bar8.move(1080, 110)
        self.bar9 = PassBar(self)
        self.bar9.move(790, 380)
        self.bar10 = PassBar(self)
        self.bar10.move(1080, 380)
        self.bar11 = PassBar(self)
        self.bar11.move(790, 640)
        self.bar12 = PassBar(self)
        self.bar12.move(1080, 640)

        self.bars = [self.bar1, self.bar2, self.bar3,
                     self.bar4, self.bar5, self.bar6,
                     self.bar7, self.bar8, self.bar9,
                     self.bar10, self.bar11, self.bar12]

    def load_image(self, file_name):
        pixmap = QtGui.QPixmap(file_name)
        self.power_label.setPixmap(pixmap)
        self.power_label.resize(pixmap.width(), pixmap.height())

    def start_sim(self):
        if self.power_is_on:
            '''if not self.platform.port_MEGA.isOpen():
                self.platform.port_DUE.open()
                self.platform.port_MEGA.open()
                self.platform.port_gyro.open()'''
            self.ports_label.setText('1-й узел подключён в ' + 'COM6' + ' 2-й узел подключён в ' + 'COM3')
            self.platform.start_simulation = True
            self.timer_update = QtCore.QTimer()  # задержка, чтоб данные успели отослаться с платы
            self.timer_update.setInterval(200)
            self.timer_update.timeout.connect(self.check_update)
            self.timer_update.start()
            #self.platform.start_com = True
            self.platform.reload = False

            self.pushButton_8.setStyleSheet(
                'QPushButton {background-color: rgb(255, 255, 255); color: rgb(85, 85, 85);}')
            self.pushButton_7.setStyleSheet("background: rgb(170, 255, 127)")

            self.checkBox_7.setChecked(False)
            self.checkBox_7.setEnabled(True)
            self.load_image("icons\on.jpg")
            self.write_to_log(self.get_time() + " " + "Нажата кнопка Старт")

        elif not self.power_is_on:
            a = WarningWindow(self, "Питание не включено!")
            a.__call__()
            self.write_to_log(self.get_time() + " " + "Попытка включения без питания!")

    def end_sim(self):
        self.platform.start_simulation = False

        self.platform.condor_main.idle()

        self.pushButton_8.setStyleSheet("background: rgb(255, 186, 67)")
        self.pushButton_7.setStyleSheet('QPushButton {background-color: rgb(255, 255, 255); color: rgb(85, 85, 85);}')
        self.platform.port_SPP.flushOutput()

        self.load_image("icons\off.jpg")
        self.write_to_log(self.get_time() + " " + "Нажата кнопка Стоп")

    def calibration_mode(self):
        self.platform.calibration_mode = True
        self.platform.condor_main.draw_limits = True
        self.platform.hand_mode = False
        self.platform.simulate_mode = False
        self.platform.demonstration_mode = False
        self.label_mode.setText("Калибровка")
        self.write_to_log(self.get_time() + " " + "Включён режим Калибровка")
        self.hand_mode_boxes()

    def show_mode(self):
        self.platform.demonstration_mode = True
        self.platform.condor_main.draw_vertexes = True
        self.platform.calibration_mode = False
        self.platform.condor_main.draw_limits = False
        self.platform.hand_mode = False
        self.platform.simulate_mode = False
        self.label_mode.setText("Демонстрационный")
        self.write_to_log(self.get_time() + " " + "Включён режим Демонстрационный")
        self.hand_mode_boxes()

    def hand_mode(self):
        self.platform.hand_mode = True
        self.platform.simulate_mode = False
        self.platform.demonstration_mode = False
        self.platform.calibration_mode = False
        self.platform.condor_main.draw_limits = False
        self.label_mode.setText("Ручной")
        self.write_to_log(self.get_time() + " " + "Включён режим Ручной")
        self.hand_mode_boxes()

    def checkCondor(self):
        for proc in psutil.process_iter():
            name = proc.name()
            if name == "Condor.exe":
                return True
        return False

    def simulate_mode(self):
        if not self.platform.simulate_mode:
            if self.checkCondor():
            #if not self.platform.simulate_mode:
                self.write_to_log(self.get_time() + " " + "Симулятор " +
                                  "обнаружен! Запуск разрешается!")
                self.platform.simulate_mode = True
                self.platform.hand_mode = False
                self.platform.demonstration_mode = False
                self.calibration_mode = False
                self.platform.calibration_mode = False
                self.platform.condor_main.draw_limits = False
                self.label_mode.setText("Симуляционный")
                self.write_to_log(self.get_time() + " " + "Включён режим Симуляция")
                self.hand_mode_boxes()
            else:
                self.write_to_log(self.get_time() + " " + "Симулятор не " +
                                  "обнаружен! Запуск не разрешается!")

    def hand_mode_boxes(self):
        boxes = [self.checkBox_6, self.checkBox_5, self.checkBox_4,
                 self.checkBox_3, self.checkBox_2, self.checkBox]
        for box in boxes:
            if self.platform.hand_mode:
                box.setEnabled(True)
                box.setChecked(True)
            else:
                box.setEnabled(False)
                box.setChecked(False)

    def system_prepare(self):
        buttons = [self.b_p1, self.b_s1, self.b_s2, self.b_p2,
                   self.b_s3, self.b_s4, self.b_p3, self.b_s5, self.b_s6,
                   self.pushButton_29, self.pushButton_11, self.pushButton_9, self.pushButton_32,
                   self.pushButton_10, self.pushButton_12, self.pushButton_30, self.pushButton_14,
                   self.pushButton_13]
        for button in buttons:
            index = buttons.index(button)
            button.clicked.connect(WarningWindow(self, texts_errors[index]))

    def dynamic_characteristic(self):
        text_edits = [self.textEdit, self.textEdit_3, self.textEdit_5,
                      self.textEdit_4, self.textEdit_2, self.textEdit_6]
        for text in enumerate(text_edits):
            index, text = text
            text.setText('Цилиндр №' + str(index + 1) + '\n' +
                         'Длина: ' + '\n' +
                         'Скорость изменения длины: ' + '\n' +
                         'Ускорение: ' + '\n' +
                         'Момент: ' + '\n' +
                         'Нагрузки: ')

    def update(self):
        if self.platform.start_simulation:
            for i in range(6):
                self.bars[i].passProgress(self.platform.bars[i])
                self.bars[i + 6].passProgress(self.platform.bars_gyro[i])
                self.plots[i].update(self.platform.l[i], self.platform.l_gyro[i])

    def reload(self):
        time = self.platform.time
        if time < self.time_to_reload + 5000:
            y = str(-255)
            outlet_com = '$' + y + ' ' + y + ' ' + y + ' ' + y + ' ' + y + ' ' + y + ';'
            self.platform.port_SPP.write(outlet_com.encode('utf-8'))
            print(outlet_com)
            self.write_to_log(self.get_time() + " " + "Втягивание всех поршней")
        else:
            self.platform.reload = False
            self.checkBox_7.setChecked(False)
            self.platform.port_SPP.flushOutput()

    def powerOn(self):
        if self.platform.start_com:
            self.power_is_on = True
            self.power_is_off = False

            if self.platform.port_SPP.isOpen():
                outlet_com1 = '$' + str(19) + ' ' + str(11) + ' ' + str(20) + ' ' + str(0) + ' ' + str(0) + ' ' + str(
                    0) + ';'
                self.platform.port_SPP.write(outlet_com1.encode('utf-8'))
            self.write_to_log(self.get_time() + " " + "Питание включено")
        else:
            stop = WarningWindow(self, "Сначала определите порты в меню Настройки!")
            stop.__call__()

    def powerOff(self):
        if not self.platform.start_simulation:
            self.power_is_on = False
            self.power_is_off = True

            if self.platform.port_SPP.isOpen():
                outlet_com1 = '$' + str(28) + ' ' + str(10) + ' ' + str(21) + ' ' + str(0) + ' ' + str(0) + ' ' + str(
                    0) + ';'
                self.platform.port_SPP.write(outlet_com1.encode('utf-8'))
            self.write_to_log(self.get_time() + " " + "Питание выключено")

            self.platform.port_SPP.flushInput()
            #self.platform.port_gyro.flushInput()

            y = str(0)
            outlet_com = '$' + y + ' ' + y + ' ' + y + ' ' + y + ' ' + y + ' ' + y + ';'
            self.platform.port_SPP.write(outlet_com.encode('utf-8'))

        else:
            a = WarningWindow(self, "Необходима остановка программы!")
            a.__call__()

    def exitProgram(self, foreign=False):
        if not foreign:
            if self.platform.start_com:
                if self.platform.port_SPP.isOpen():
                    outlet_com1 = '$' + str(28) + ' ' + str(10) + ' ' + str(21) + ' ' + str(0) + ' ' + str(0) + ' ' + str(
                        0) + ';'
                    self.platform.port_SPP.write(outlet_com1.encode('utf-8'))
        sys.exit()

    def check_update(self):
        if self.platform.start_com:
            buttoms = [self.b_p1, self.b_s1, self.b_s2, self.b_p2,
                       self.b_s3, self.b_s4, self.b_p3, self.b_s5, self.b_s6,
                       self.pushButton_29, self.pushButton_11, self.pushButton_9, self.pushButton_32,
                       self.pushButton_10, self.pushButton_12, self.pushButton_30, self.pushButton_14,
                       self.pushButton_13]
            '''a = self.platform.port_SPP.readline().strip()
            prepare = a.decode('utf-8', errors='ignore')
            data = []
            for i in prepare:
                data.append(i)
            for j in buttoms:
                index = buttoms.index(j)
                if data[index] == '1':
                    j.setStyleSheet("background-color: green")
                elif data[index] == '0':
                    j.setStyleSheet("background-color: red")
            self.platform.port_SPP.flushInput()'''

            for j in buttoms:
                j.setStyleSheet("background-color: green")

    def write_to_log(self, text):
        file = open("LogFileCOM.txt", "a")
        file.write(text + '\n')
        file.close

        file = open("LogFileCOM.txt", "r")
        self.textEdit_7.setText(file.read())
        self.textEdit_7.isReadOnly()
        self.textEdit_7.moveCursor(QtGui.QTextCursor.End)

    def get_time(self):
        data = datetime.now()
        return str(data.hour) + ":" + str(data.minute) + ":" + str(data.second)


class Graph:
    def __init__(self, plot):
        self.plot = plot
        self.dat1 = deque()
        self.dat2 = deque()
        self.maxLen = 50  # max number of data points to show on graph
        self.plot.setWindowTitle('Цилиндр')
        self.plot.addLegend()
        self.do_plot1 = self.plot.plot(pen='r', name='ЦЦ')
        self.do_plot2 = self.plot.plot(pen='g', name='АЦ')

    def update(self, data1, data2):
        if len(self.dat1) > self.maxLen:
            self.dat1.popleft()  # remove oldest
        if len(self.dat2) > self.maxLen:
            self.dat2.popleft()  # remove oldest
        # self.dat.append(random.randint(0, 100))
        self.dat1.append(data1)
        self.do_plot1.setData(self.dat1)

        self.dat2.append(data2)
        self.do_plot2.setData(self.dat2)


class PassBar(QtWidgets.QWidget):
    def __init__(self, a0: QtWidgets.QWidget):
        super(PassBar, self).__init__(a0)
        self.setGeometry(0, 0, 5, 210)
        self.progress = 0

    def paintEvent(self, a0: QtGui.QPaintEvent) -> None:
        painter = QtGui.QPainter(self)
        painter.setPen(QtCore.Qt.NoPen)
        if self.progress > 1:
            painter.setBrush(QtCore.Qt.red)
        else:
            painter.setBrush(QtCore.Qt.blue)
        progressHeight = int(self.height() * self.progress)
        painter.drawRect(0, self.height() - progressHeight, self.width(), progressHeight)
        painter.setPen(QtCore.Qt.black)
        painter.setBrush(QtCore.Qt.NoBrush)
        painter.drawRect(0, 0, self.width() - 1, self.height() - 1)

    def passProgress(self, progress):
        self.progress = progress
        self.update()


class WarningWindow(QtWidgets.QWidget):
    def __init__(self, ren, text):
        self.ren = ren
        self.text = text
        self.left = 10
        self.top = 10
        self.width = 320
        self.height = 200

    def __call__(self):
        self.WarningMessage()

    def WarningMessage(self):
        self.warningMessage = QtWidgets.QMessageBox(self.ren)
        self.warningMessage.setWindowTitle("Неисправность в узле")
        self.warningMessage.setText(self.text)
        self.warningMessage.setWindowIcon(QtGui.QIcon('icons\warning.ico'))
        self.warningMessage.setStandardButtons(QtWidgets.QMessageBox.StandardButton.Cancel |
                                               QtWidgets.QMessageBox.StandardButton.Ok)
        self.warningMessage.setDefaultButton(QtWidgets.QMessageBox.StandardButton.Ok)
        self.warningMessage.setDetailedText("Написано, как решать проблему!")
        self.warningMessage.exec_()


class ConsolWindow(QtWidgets.QWidget, Ui_Form):
    def __init__(self):
        super(ConsolWindow, self).__init__()
        self.setupUi(self)
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint)
        self.save_time_DR.clicked.connect(self.write_the_time)
        self.set_old_text()

    def __call__(self):
        self.show()

    def set_old_text(self):
        volumes = [self.up_edit, self.down_edit, self.mid_edit,
                   self.rotL_edit, self.rotR_edit, self.rotM_edit]
        file = open("DemostrationMode.txt", 'r')
        data = file.readline()
        data = data.split()
        file.close()

        for volume in enumerate(volumes):
            index, volume = volume
            if len(data) == 6:
                volume.setText(data[index])
            else:
                volume.setText('0')

    def write_the_time(self):
        file = open("DemostrationMode.txt", 'w')
        volumes = [self.up_edit.text(), self.down_edit.text(), self.mid_edit.text(),
                   self.rotL_edit.text(), self.rotR_edit.text(), self.rotM_edit.text()]
        for volume in volumes:
            if volume == ' ':
                volume = 0
        file.write(
            " ".join(volumes)
        )
        file.close()


class LoadWindow(QtWidgets.QWidget, Ui_load_window):
    titles = ['Основной процессор управления', 'Гироскоп']
    def __init__(self, load):
        super(LoadWindow, self).__init__()
        self.setupUi(self)
        self.load = load
        self.setWindowIcon(QtGui.QIcon("icons\setings.png"))
        self.setWindowFlags(self.windowFlags() | QtCore.Qt.WindowStaysOnTopHint |
                            QtCore.Qt.FramelessWindowHint)
        self.setAttribute(QtCore.Qt.WA_DeleteOnClose, True)
        self.ports = ['0', '0']
        self.start_image()
        self.buttons()
        self.show()

        self.get_ports()

    def update(self):
        signs = [self.L_m, self.L_g]
        for _ in range(len(signs)):
            if self.ports[_] != '0':
                self.load_button_image("icons\on.jpg", signs[_])
            else:
                self.load_button_image("icons\off.jpg", signs[_])
        if self.ports[0] != '0' and self.ports[1] != '0':
            self.buttom_ok.setEnabled(True)
        self.buttom_ok.setEnabled(True)
        print(self.ports)

    def get_ports(self):
        self.ports[0] = self.set_the_ports(self.titles[0], 115200, b'm')
        self.update()
        self.ports[1] = self.set_the_ports(self.titles[1], 57600, b'g')
        self.update()
        if self.ports[0] == '0':
            warning = WarningWindow(self, "Основная плата не найдена! Запуск не возможен!"
                                          " Проверьте подключение и повторите попытку поиска портов!")
            warning.__call__()
        if self.ports[1] == '0':
            warning = WarningWindow(self, "Гироскоп не найден! Запуcк не возможен!"
                                          " Проверьте подключение и повторите попытку поиска портов!")
            warning.__call__()

    def buttons(self):
        self.button_close.clicked.connect(self.exit)
        self.buttom_ok.clicked.connect(self.start)
        self.repeat_button.clicked.connect(self.get_ports)

    def start(self):
        if self.buttom_ok.isEnabled():
            self.load.platform.start_ports(self.ports)
            self.load.platform.start_com = True
            self.close()

    def exit(self):
        self.close()
        #self.load.exitProgram(foreign=True)

    def start_image(self):
        self.load_button_image("icons\off.jpg", self.L_g)
        self.load_button_image("icons\off.jpg", self.L_m)
        self.buttom_ok.setEnabled(False)

    def load_button_image(self, file_name, label):
        pixmap = QtGui.QPixmap(file_name)
        label.setPixmap(pixmap)
        label.resize(pixmap.width(), pixmap.height())

    def set_the_ports(self, title, speed, data):
        """Функция автоопределения портов. Принимаем в кач-ве аргументов:
        названия подлючённого модуля, битрейт, байт-сигнал о подключении."""
        ports = self.serial_ports()  # полчаем список все досутпных портов
        for port in ports:
            port_test = serial.Serial(port, speed)
            time.sleep(1)  # время на открытие порта!
            count = 0
            while not port_test.inWaiting() and count != 3:
                #print("Ожидание данных от " + title + "!")
                self.load.write_to_log("Ожидание данных от " + title + "!")
                time.sleep(1)
                count += 1
                #print (count)
            if port_test.inWaiting():
                if port_test.read() == data:
                    port_test.close()
                    #print(title + " найден!" + str(port))
                    self.load.write_to_log(title + " найден!" + str(port))
                    return port
            else:
                port_test.close()
        self.load.write_to_log(title + " не найден!")
        #print(title + " не найден!")
        return '0'

    def serial_ports(self):
        if sys.platform.startswith('win'):
            ports = ['COM%s' % (i + 1) for i in range(256)]
        else:
            raise EnvironmentError('Unsupported platform')

        result = []
        for port in ports:
            try:
                s = serial.Serial(port)
                s.close()
                result.append(port)
            except (OSError, serial.SerialException):
                pass
        return result
