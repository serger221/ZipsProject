import serial  # подключаем библиотеку для последовательной связи
import time  # подключаем библиотеку чтобы задействовать функции задержки в программе
import numpy as np
import math
import pygame as pg
import glob
from datetime import datetime

pg.init()
#pg.joystick.init()
hoy = pg.joystick.Joystick(0)
hoy.init()
#print(hoy.get_numaxes())
a = np.array([1, 2, 3])
print(a*3)

def serial_ports():
    """ Lists serial port names

        :raises EnvironmentError:
            On unsupported or unknown platforms
        :returns:
            A list of the serial ports available on the system
    """
    if sys.platform.startswith('win'):
        ports = ['COM%s' % (i + 1) for i in range(256)]
    elif sys.platform.startswith('linux') or sys.platform.startswith('cygwin'):
        # this excludes your current terminal "/dev/tty"
        ports = glob.glob('/dev/tty[A-Za-z]*')
    elif sys.platform.startswith('darwin'):
        ports = glob.glob('/dev/tty.*')
    else:
        raise EnvironmentError('Unsupported platform')

    result = []
    for port in ports:
        try:
            s = serial.Serial(port)
            s.close()
            result.append(port)
        except (OSError, serial.SerialException):
            pass
    return result

def filter_mid(array):
    if array[1] < array[0] < array[2] or array[2] < array[0] < array[1]:
        return array[0]
    elif array[0] < array[1] < array[2] or array[2] < array[1] < array[0]:
        return array[1]
    else:
        return array[2]

def middle(array):
    array.sort()
    return array[1]

#print(filter_mid(a))

def UPD():
    UDP_IP = "127.0.0.1"
    UDP_PORT = 55278

    sock = socket.socket(socket.AF_INET,  # Интернет
                         socket.SOCK_DGRAM)  # UDP
    sock.bind((UDP_IP, UDP_PORT))

    l = []  # Массив для данных

    while True:
        data, addr = sock.recvfrom(1024)  # Размер буфера передачи
        a = data.decode("utf-8")  # Перекодировка содержимого из байт-строк в строки
        index_in = a.find('yaw=')  # Индекс начала парметра
        index_out = a.find('pitch=') - 2  # Из индекса начала след.парметра вычитаем символ переноса
        l.append(a[index_in:index_out])  # Добавляем в массив выраз
        transf = re.findall(r'\d*\.\d+|\d+', l[0])  # Вычленяем числа из строки
        f_num = [float(i) for i in transf]  # Превращаем в вещественные
        print(f_num[0])
        l.clear()  # Очищаем массив для след. приёма

 ###ФУНКЦИИ НЕ НУЖНЫЕ ПОКА###
def check_port(host, port):  # Метод проверки открытости порта UPD
    sock = socket.socket(socket.AF_INET,  # Интернет
                            socket.SOCK_DGRAM)  # UDP
    sock.settimeout(1)
    try:
        result = sock.connect_ex((host, port))
    except socket.gaierror:
        sock.close()
        return 1
    sock.close()
    return result

def ex_proc():
    PROCNAME = "Condor.exe"
    for proc in psutil.process_iter():
        try:
            if proc.name() == PROCNAME:
                return True
        except (psutil.NoSuchProcess, psutil.AccessDenied, psutil.ZombieProcess):
            return False